export { FooterInfoWrapperSection } from "./FooterInfoWrapperSection";

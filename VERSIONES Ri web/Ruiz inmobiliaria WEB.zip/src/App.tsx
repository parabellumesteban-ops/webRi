﻿import { RouterProvider, createBrowserRouter } from "react-router-dom";
import { Alianzas } from "./screens/Alianzas/Alianzas";
import { CertRi } from "./screens/CertRi/CertRi";
import { ConoceRi } from "./screens/ConoceRi";
import { Contacto } from "./screens/Contacto";
import { HomeScreen } from "./screens/HomeScreen/HomeScreen";
import { Proyectos } from "./screens/Proyectos/Proyectos";

const router = createBrowserRouter([
  {
    path: "/",
    element: <HomeScreen />,
  },
  {
    path: "/home",
    element: <HomeScreen />,
  },
  {
    path: "/cert-ri",
    element: <CertRi />,
  },
  {
    path: "/alianzas",
    element: <Alianzas />,
  },
  {
    path: "/proyectos",
    element: <Proyectos />,
  },
  {
    path: "/contacto",
    element: <Contacto />,
  },
  {
    path: "/conoce-ri",
    element: <ConoceRi />,
  },
]);

export const App = () => {
  return (
    <>
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[9999] focus:rounded-md focus:bg-white focus:px-4 focus:py-2 focus:text-black focus:outline-none focus:ring-2 focus:ring-black"
      >
        Saltar al contenido principal
      </a>

      <main id="main-content" tabIndex={-1} className="w-full">
        <RouterProvider router={router} />
      </main>
    </>
  );
};

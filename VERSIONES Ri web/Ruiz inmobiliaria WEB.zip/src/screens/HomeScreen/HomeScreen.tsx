﻿import { FooterInfoWrapperSection } from "./sections/FooterInfoWrapperSection";
import { GrowthOpportunityWrapperSection } from "./sections/GrowthOpportunityWrapperSection/GrowthOpportunityWrapperSection";
import { HeroImageWrapperSection } from "./sections/HeroImageWrapperSection";
import { SeoHead } from "../../components/SeoHead";

export const HomeScreen = (): JSX.Element => {
  return (
    <>
      <SeoHead
        title="Ruiz Inmobiliaria | Inversion inmobiliaria en Jalisco"
        description="Invierte en proyectos inmobiliarios con respaldo, asesoria y acompanamiento profesional en Jalisco."
        canonicalPath="/"
      />
    <div
      className="flex flex-col w-full items-center bg-white"
      data-model-id="119:1289"
    >
      <HeroImageWrapperSection />
      <GrowthOpportunityWrapperSection />
      <FooterInfoWrapperSection />
    </div>
    </>
  );
};



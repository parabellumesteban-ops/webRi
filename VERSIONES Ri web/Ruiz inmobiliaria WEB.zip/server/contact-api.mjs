﻿import express from "express";
import { mkdir, appendFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import crypto from "node:crypto";
import nodemailer from "nodemailer";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dataDir = path.join(__dirname, "data");
const leadsFile = path.join(dataDir, "contact-leads.ndjson");

const app = express();
const port = Number(process.env.CONTACT_API_PORT || 8787);
const destinationEmail = process.env.CONTACT_TO_EMAIL || "support.ri@ruizinmobiliaria.com";
const senderEmail = process.env.CONTACT_FROM_EMAIL || process.env.SMTP_USER || "support.ri@ruizinmobiliaria.com";

app.use(express.json({ limit: "100kb" }));

const normalizePhone = (value = "") => value.replace(/\D/g, "");
const isValidEmail = (value = "") => /\S+@\S+\.\S+/.test(value);

const validatePayload = (payload = {}) => {
  const errors = {};

  if (!String(payload.nombre || "").trim()) errors.nombre = "Nombre requerido.";
  if (!String(payload.apellidoPaterno || "").trim()) {
    errors.apellidoPaterno = "Apellido paterno requerido.";
  }

  const phoneDigits = normalizePhone(payload.telefono || "");
  if (phoneDigits.length < 10) errors.telefono = "Telefono invalido.";

  if (!isValidEmail(String(payload.correo || ""))) {
    errors.correo = "Correo invalido.";
  }

  if (!String(payload.ayuda || "").trim()) {
    errors.ayuda = "Tipo de consulta requerido.";
  }

  return errors;
};

const createMailTransport = () => {
  const host = process.env.SMTP_HOST;
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;

  if (!host || !user || !pass) {
    return null;
  }

  return nodemailer.createTransport({
    host,
    port: Number(process.env.SMTP_PORT || 465),
    secure: String(process.env.SMTP_SECURE || "true").toLowerCase() !== "false",
    auth: {
      user,
      pass,
    },
  });
};

const buildMailHtml = (lead) => `
  <div style="font-family:Arial,sans-serif;line-height:1.6;color:#222;max-width:640px">
    <h2 style="margin:0 0 16px;color:#4D4C4F;">Nuevo formulario de contacto</h2>
    <p><strong>Fecha:</strong> ${lead.createdAt}</p>
    <p><strong>Nombre:</strong> ${lead.nombre} ${lead.apellidoPaterno} ${lead.apellidoMaterno}</p>
    <p><strong>Telefono:</strong> ${lead.telefono}</p>
    <p><strong>Correo:</strong> ${lead.correo}</p>
    <p><strong>Consulta:</strong> ${lead.ayuda}</p>
    <p><strong>Origen:</strong> ${lead.source}</p>
  </div>
`;

const sendLeadEmail = async (lead) => {
  const transporter = createMailTransport();

  if (!transporter) {
    console.warn("[contact-api] SMTP no configurado. El lead se guardo localmente, pero no se envio por correo.");
    return false;
  }

  await transporter.sendMail({
    from: senderEmail,
    to: destinationEmail,
    replyTo: lead.correo,
    subject: `Nuevo lead web: ${lead.nombre} ${lead.apellidoPaterno}`,
    text: [
      "Nuevo formulario de contacto",
      `Fecha: ${lead.createdAt}`,
      `Nombre: ${lead.nombre} ${lead.apellidoPaterno} ${lead.apellidoMaterno}`,
      `Telefono: ${lead.telefono}`,
      `Correo: ${lead.correo}`,
      `Consulta: ${lead.ayuda}`,
      `Origen: ${lead.source}`,
    ].join("\n"),
    html: buildMailHtml(lead),
  });

  return true;
};

app.get("/api/health", (_req, res) => {
  res.status(200).json({ ok: true, service: "contact-api" });
});

app.post("/api/contact", async (req, res) => {
  const errors = validatePayload(req.body);
  if (Object.keys(errors).length > 0) {
    return res.status(400).json({ ok: false, message: "Payload invalido.", errors });
  }

  const lead = {
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
    nombre: String(req.body.nombre || "").trim(),
    apellidoPaterno: String(req.body.apellidoPaterno || "").trim(),
    apellidoMaterno: String(req.body.apellidoMaterno || "").trim(),
    telefono: normalizePhone(req.body.telefono || ""),
    correo: String(req.body.correo || "").trim().toLowerCase(),
    ayuda: String(req.body.ayuda || "").trim(),
    source: "website",
  };

  try {
    await mkdir(dataDir, { recursive: true });
    await appendFile(leadsFile, JSON.stringify(lead) + "\n", "utf8");

    await sendLeadEmail(lead);

    const webhookUrl = process.env.CONTACT_WEBHOOK_URL;
    if (webhookUrl) {
      await fetch(webhookUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(lead),
      });
    }

    return res.status(201).json({
      ok: true,
      message: "Lead recibido correctamente.",
      leadId: lead.id,
    });
  } catch (error) {
    console.error("Error processing contact lead", error);
    return res.status(500).json({
      ok: false,
      message: "No se pudo guardar el lead. Intenta de nuevo.",
    });
  }
});

app.listen(port, () => {
  console.log(`[contact-api] running at http://localhost:${port}`);
});

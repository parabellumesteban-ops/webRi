﻿import { useEffect, useState } from "react";

type RemoteImageProps = {
  src: string;
  alt: string;
  className?: string;
  fallbackSrc?: string;
  loading?: "eager" | "lazy";
  decoding?: "async" | "auto" | "sync";
  fetchPriority?: "high" | "low" | "auto";
};

const defaultFallback =
  "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='320' height='200'><rect width='100%' height='100%' fill='%23e5e7eb'/><text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' fill='%236b7280' font-size='16' font-family='Arial'>Imagen no disponible</text></svg>";

export const RemoteImage = ({
  src,
  alt,
  className,
  fallbackSrc = defaultFallback,
  loading = "lazy",
  decoding = "async",
  fetchPriority = "auto",
}: RemoteImageProps): JSX.Element => {
  const [currentSrc, setCurrentSrc] = useState(src);
  const [didFallback, setDidFallback] = useState(false);

  useEffect(() => {
    setCurrentSrc(src);
    setDidFallback(false);
  }, [src]);

  return (
    <img
      src={currentSrc}
      alt={alt}
      loading={loading}
      decoding={decoding}
      fetchPriority={fetchPriority}
      className={className}
      onError={() => {
        if (!didFallback) {
          setCurrentSrc(fallbackSrc);
          setDidFallback(true);
        }
      }}
    />
  );
};

export { ConoceRi } from "./ConoceRi";

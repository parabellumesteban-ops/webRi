﻿import { AboutUsSection } from "./sections/AboutUsSection";
import { TeamAndContactSection } from "./sections/TeamAndContactSection/TeamAndContactSection";
import { SeoHead } from "../../components/SeoHead";

export const ConoceRi = (): JSX.Element => {
  return (
    <>
      <SeoHead
        title="Conoce RI | Ruiz Inmobiliaria"
        description="Descubre nuestra historia, valores y equipo para invertir con confianza en bienes raices."
        canonicalPath="/conoce-ri"
      />
    <div
      className="flex flex-col w-full items-center justify-center bg-white"
      data-model-id="104:1423"
    >
      <AboutUsSection />
      <TeamAndContactSection />
    </div>
    </>
  );
};



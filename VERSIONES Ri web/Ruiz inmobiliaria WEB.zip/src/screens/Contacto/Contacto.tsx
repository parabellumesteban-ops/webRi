﻿import { ContactFormSection } from "./sections/ContactFormSection";
import { ContactInfoSection } from "./sections/ContactInfoSection";
import { SeoHead } from "../../components/SeoHead";

export const Contacto = (): JSX.Element => {
  return (
    <>
      <SeoHead
        title="Contacto | Ruiz Inmobiliaria"
        description="Habla con nuestro equipo y recibe orientacion personalizada sobre tu siguiente inversion inmobiliaria."
        canonicalPath="/contacto"
      />
    <div
      className="flex flex-col w-full items-center justify-center relative bg-white"
      data-model-id="1:1357"
    >
      <ContactFormSection />
      <ContactInfoSection />
    </div>
    </>
  );
};



import { ContactCtaSection } from "./sections/ContactCtaSection/ContactCtaSection";
import { HeroSection } from "./sections/HeroSection/HeroSection";
import { ProjectDetailsSection } from "./sections/ProjectDetailsSection/ProjectDetailsSection";
import { SeoHead } from "../../components/SeoHead";

export const TorreDelBosque = (): JSX.Element => {
  return (
    <>
      <SeoHead
        title="Torre del Bosque | Ruiz Inmobiliaria"
        description="Descubre Torre del Bosque: ubicacion estrategica, amenidades premium y planes de pago flexibles para invertir con confianza."
        canonicalPath="/proyectos/torre-del-bosque"
      />

      <div className="flex w-full flex-col items-center bg-white">
        <HeroSection />
        <ProjectDetailsSection />
        <ContactCtaSection />
      </div>
    </>
  );
};

﻿import { useEffect } from "react";

type SeoHeadProps = {
  title: string;
  description: string;
  canonicalPath?: string;
  imagePath?: string;
};

const upsertMeta = (
  attr: "name" | "property",
  key: string,
  content: string,
): void => {
  let meta = document.head.querySelector<HTMLMetaElement>(`meta[${attr}='${key}']`);

  if (!meta) {
    meta = document.createElement("meta");
    meta.setAttribute(attr, key);
    document.head.appendChild(meta);
  }

  meta.setAttribute("content", content);
};

const upsertLink = (rel: string, href: string): void => {
  let link = document.head.querySelector<HTMLLinkElement>(`link[rel='${rel}']`);

  if (!link) {
    link = document.createElement("link");
    link.setAttribute("rel", rel);
    document.head.appendChild(link);
  }

  link.setAttribute("href", href);
};

export const SeoHead = ({
  title,
  description,
  canonicalPath,
  imagePath = "/favicon.svg",
}: SeoHeadProps): null => {
  useEffect(() => {
    const origin = window.location.origin;
    const path = canonicalPath ?? window.location.pathname;
    const canonicalUrl = new URL(path, origin).toString();
    const imageUrl = new URL(imagePath, origin).toString();

    document.title = title;

    upsertMeta("name", "description", description);
    upsertMeta("name", "theme-color", "#FCB640");

    upsertMeta("property", "og:title", title);
    upsertMeta("property", "og:description", description);
    upsertMeta("property", "og:type", "website");
    upsertMeta("property", "og:url", canonicalUrl);
    upsertMeta("property", "og:image", imageUrl);

    upsertMeta("name", "twitter:card", "summary");
    upsertMeta("name", "twitter:title", title);
    upsertMeta("name", "twitter:description", description);
    upsertMeta("name", "twitter:image", imageUrl);

    upsertLink("canonical", canonicalUrl);
    upsertLink("icon", "/favicon.svg");
  }, [title, description, canonicalPath, imagePath]);

  return null;
};

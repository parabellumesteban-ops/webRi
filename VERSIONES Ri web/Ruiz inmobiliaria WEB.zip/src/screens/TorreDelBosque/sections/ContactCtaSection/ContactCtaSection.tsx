import { Footer } from "../../../../components/Footer";
import { Button } from "../../../../components/ui/button";

export const ContactCtaSection = (): JSX.Element => {
  return (
    <section className="w-full">
      <div className="flex w-full justify-center bg-[#4D4C4F] px-5 py-16 md:px-20">
        <div className="flex w-full max-w-[1440px] flex-col items-center gap-6 text-center">
          <h2 className="[font-family:'Montserrat',Helvetica] text-4xl font-bold text-white md:text-5xl">
            Recibe Brochure y Disponibilidad
          </h2>
          <p className="max-w-[920px] ri-body !text-white">
            Nuestro equipo te acompana para elegir la unidad ideal segun tu presupuesto y objetivo de inversion.
          </p>

          <Button
            asChild
            className="h-auto rounded-[15px] bg-[#FCB640] px-8 py-4 [font-family:'Montserrat',Helvetica] text-2xl font-semibold text-white hover:bg-[#FCB640]/90"
          >
            <a href="https://wa.link/y9cz4x" target="_blank" rel="noopener noreferrer">
              Quiero asesoria personalizada
            </a>
          </Button>
        </div>
      </div>

      <Footer />
    </section>
  );
};

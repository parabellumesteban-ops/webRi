﻿import { AllianceDetailsSection } from "./sections/AllianceDetailsSection/AllianceDetailsSection";
import { AllianceOverviewSection } from "./sections/AllianceOverviewSection/AllianceOverviewSection";
import { SeoHead } from "../../components/SeoHead";

export const Alianzas = (): JSX.Element => {
  return (
    <>
      <SeoHead
        title="Alianzas | Ruiz Inmobiliaria"
        description="Explora nuestro modelo de alianzas y colaboraciones para crecer contigo en el sector inmobiliario."
        canonicalPath="/alianzas"
      />
    <main
      className="flex flex-col w-full items-center bg-white"
      data-model-id="1:513"
    >
      <AllianceOverviewSection />
      <AllianceDetailsSection />
    </main>
    </>
  );
};



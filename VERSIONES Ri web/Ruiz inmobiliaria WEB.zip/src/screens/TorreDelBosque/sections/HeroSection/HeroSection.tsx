import { MenuIcon, XIcon } from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Button } from "../../../../components/ui/button";
import { getNavLinkClassName, navigationLinks } from "../../../../lib/navigation";

export const HeroSection = (): JSX.Element => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  return (
    <section
      className="relative flex h-[720px] w-full items-center justify-center bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage:
          "linear-gradient(180deg, rgba(28,29,31,0.45) 0%, rgba(28,29,31,0.72) 100%), url(https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1800&q=80)",
      }}
    >
      <header className="absolute left-1/2 top-0 z-50 flex h-[150px] w-full max-w-[1440px] -translate-x-1/2 items-center justify-between px-5 py-8 md:px-20">
        <Link to="/home" className="flex-shrink-0">
          <img
            className="h-[96px] w-[60px]"
            alt="Ruiz Inmobiliaria"
            src="https://c.animaapp.com/mmjez8tnoH67O3/img/capa-1.svg"
            loading="eager"
            decoding="async"
          />
        </Link>

        <nav aria-label="Navegacion principal" className="hidden flex-1 items-center justify-end gap-[30px] md:flex">
          {navigationLinks.map((link) => (
            <Link key={link.to} className={getNavLinkClassName(location.pathname, link.to)} to={link.to}>
              {link.label}
            </Link>
          ))}
        </nav>

        <Button
          variant="ghost"
          size="icon"
          className="z-50 bg-transparent text-white hover:bg-transparent md:hidden"
          aria-label="Abrir menu"
          aria-expanded={mobileMenuOpen}
          aria-controls="mobile-nav-torre"
          onClick={() => setMobileMenuOpen((current) => !current)}
        >
          {mobileMenuOpen ? <XIcon className="h-9 w-9" /> : <MenuIcon className="h-8 w-8" />}
        </Button>

        {mobileMenuOpen && (
          <nav
            id="mobile-nav-torre"
            aria-label="Navegacion movil"
            className="fixed right-5 top-24 z-50 flex flex-col items-end gap-4 pt-4 md:hidden [&_a]:text-right [&_a]:text-[24px] [&_a]:leading-tight [&_a]:font-normal"
          >
            {navigationLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                onClick={() => setMobileMenuOpen(false)}
                className={getNavLinkClassName(location.pathname, link.to)}
              >
                {link.label}
              </Link>
            ))}
          </nav>
        )}
      </header>

      <div className="mx-auto flex w-full max-w-[1440px] flex-col items-start gap-6 px-5 pt-20 text-white md:px-20">
        <p className="ri-body !text-white/90">Proyecto Residencial en Zapopan</p>
        <h1 className="[font-family:'Montserrat',Helvetica] text-5xl font-bold leading-[1.02] tracking-[0] md:text-7xl">
          TORRE DEL
          <br />
          <span className="text-[#FCB640]">BOSQUE</span>
        </h1>
        <p className="max-w-[700px] ri-body !text-white">
          Un desarrollo vertical pensado para quienes buscan plusvalia, conectividad y estilo de vida.
          Vive cerca de todo con amenidades premium y una propuesta arquitectonica contemporanea.
        </p>

        <Button
          asChild
          className="h-auto rounded-[15px] bg-[#FCB640] px-8 py-4 [font-family:'Montserrat',Helvetica] text-2xl font-semibold text-white hover:bg-[#FCB640]/90"
        >
          <a href="https://wa.link/y9cz4x" target="_blank" rel="noopener noreferrer">
            Agenda una visita
          </a>
        </Button>
      </div>
    </section>
  );
};

import { CheckCircle2 } from "lucide-react";
import { RemoteImage } from "../../../../components/RemoteImage";
import { Card, CardContent } from "../../../../components/ui/card";

const highlights = [
  "Ubicacion privilegiada a minutos de periferico y avenidas clave.",
  "Amenidades exclusivas: rooftop, coworking, gimnasio y terraza social.",
  "Departamentos de alta demanda para renta tradicional y ejecutiva.",
  "Esquemas de inversion con enganche desde $120,000 MXN.",
];

const specs = [
  { label: "Niveles", value: "16" },
  { label: "Unidades", value: "92" },
  { label: "Superficie", value: "Desde 62 m2" },
  { label: "Entrega", value: "2027" },
];

const galleryImages = [
  "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1200&q=80",
  "https://images.unsplash.com/photo-1484154218962-a197022b5858?auto=format&fit=crop&w=1200&q=80",
  "https://images.unsplash.com/photo-1617098474202-0d0d7f60af65?auto=format&fit=crop&w=1200&q=80",
];

export const ProjectDetailsSection = (): JSX.Element => {
  return (
    <section className="flex w-full flex-col items-center gap-16 px-5 py-16 md:px-20 md:py-20">
      <div className="grid w-full max-w-[1440px] gap-12 md:grid-cols-2 md:gap-16">
        <div className="flex flex-col gap-6">
          <h2 className="ri-h3-strong">
            Inversion estrategica con potencial real de crecimiento
          </h2>
          <p className="ri-body">
            Torre del Bosque combina ubicacion, arquitectura y rentabilidad en una sola oportunidad.
            Es ideal para inversionistas que buscan flujo por renta y apreciacion de capital a mediano plazo.
          </p>

          <div className="flex flex-col gap-4">
            {highlights.map((item) => (
              <div key={item} className="flex items-start gap-3">
                <CheckCircle2 className="mt-1 h-6 w-6 flex-shrink-0 text-[#FCB640]" />
                <p className="ri-body">{item}</p>
              </div>
            ))}
          </div>
        </div>

        <Card className="border border-[#FCB640]/35 bg-[#FCB640]/10 shadow-none">
          <CardContent className="grid gap-6 p-8">
            <h3 className="[font-family:'Montserrat',Helvetica] text-3xl font-bold text-[#4D4C4F]">
              Ficha del Proyecto
            </h3>

            <div className="grid gap-4">
              {specs.map((item) => (
                <div
                  key={item.label}
                  className="flex items-center justify-between border-b border-[#4D4C4F]/20 pb-3"
                >
                  <span className="[font-family:'Montserrat',Helvetica] text-lg font-medium text-[#4D4C4F]">
                    {item.label}
                  </span>
                  <span className="[font-family:'Montserrat',Helvetica] text-lg font-bold text-[#4D4C4F]">
                    {item.value}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid w-full max-w-[1440px] gap-5 md:grid-cols-3">
        {galleryImages.map((src, index) => (
          <RemoteImage
            key={`torre-del-bosque-${index}`}
            src={src}
            alt={`Torre del Bosque vista ${index + 1}`}
            className="h-[260px] w-full rounded-[20px] object-cover"
          />
        ))}
      </div>
    </section>
  );
};
